Beacon Bio-Card (v1)
====

V1 of this component is on Deprecation path in Foundation 3. Please use V2 of this component.

## Features
* Configurable **Layout** via select dropdown `layout`
* Configurable **Template**  via select dropdown `./template`
* Configurable **Hero-Position**  via select dropdown `./heroPosition`
* Configurable **Footnote**  via textfield `./footnote`

## Use Object
The Bio-Card component uses `com.trp.aem.trp-compose.core.models.BioCard` and Sling models as its Use-objects. (Example)

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5