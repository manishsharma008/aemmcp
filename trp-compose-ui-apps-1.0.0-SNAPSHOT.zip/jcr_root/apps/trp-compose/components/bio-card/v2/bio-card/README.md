Beacon Bio-Card (v2)
====

Bio Card compatible with Foundation V3.


## Features
* Configurable **Layout** via select dropdown `./layout`
* Configurable **Template**  via select dropdown `./template`
* Configurable **Hero-Position**  via select dropdown `./heroPosition`
* Configurable **Footnote**  via textfield `./footnote`
* Configurable **First Name**  via textfield `./firstName`
* Configurable **Last name**  via textfield `./lastName`
* Configurable **Job Title**  via textfield `./jobTitle`
* Configurable **Avatar URL**  via pathfield `./avatarUrl`
* Configurable **Bio URL**  via textfield `./bioUrl`
* Configurable **Bio Description**  via textfield `./bio`
* Configurable **ID**  via textfield `./id`
* Configurable **Use V2 ID Card**  via toggle `./v2idCard`
* Configurable **DataList**  via checkbox `./dataList`

## Use Object
The Bio-Card component uses `com.trp.aem.trp-compose.core.models.BioCard` and Sling models as its Use-objects. (Example)

## Information
* **Vendor**: T.Rowe Price
* **Version**: v2
* **Compatibility**: AEM 6.5
