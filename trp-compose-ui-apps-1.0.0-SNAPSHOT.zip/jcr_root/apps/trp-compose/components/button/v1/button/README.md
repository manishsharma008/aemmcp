Beacon Button (v1)
====

## Features
* Configurable **Button Variant** via select dropdown `./buttonVariant`
* Configurable **Button Scale** via select dropdown `./buttonScale`
* Configurable **Disable Button** via checkbox `./buttonDisable`
* Configurable **Button Icon** via asset selector `./iconFile`
* Configurable **Icon Alignment** via select dropdown `./iconAlign`
* Configurable **Text**  `./text`
* Configurable **Link**  `./link`
* Configurable **Icon**  `./icon`
* Configurable ID attribute `./id`
* Configurable ID attribute `./buttonTarget`
* Performance Tab
* Style (Mode) Tab

## Use Object
The Button component uses `com.trp.beacon.compose.core.models.button.v1.Button` and Sling models as its Use-objects.

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
