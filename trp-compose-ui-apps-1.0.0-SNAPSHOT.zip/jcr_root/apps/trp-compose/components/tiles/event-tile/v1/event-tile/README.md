Beacon Event Tile (v1)
====
This component is created to show the Event Tile Components.

## Usage
This component can be configured in 2 ways

The first is to reference the event page directly. Once configured the Event Tile will render using the content from the content fragment referenced by the page
The second is to select to override a limited selection of fields whereby an author can manually enter the content that will be rendered in the Event Tile itself

## Properties
All properties from Base Tile and following additional properties:


## Use Object
The component uses **TBD** and Sling models as its Use-objects.

## JavaScript post render processing
Some information is modified by JavaScript after the component is rendered based on some information only available in the frontend. This processing is done in the `compose.event-tile.v1.event-tile` clientlib.
The following properties are modified:
 - based on the value of the cookie 'registeredOn24EventIds' the Register is shown or a message is shown to indicate that the user is already registered for the event. This cookie is set in the compose component event-form.

[//]: # ( - the event date and time is changed to display the time in the user's current timezone. )

After post processing the component is marked as ready by adding the class `event-status-ready` to the component's main action zone.

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
