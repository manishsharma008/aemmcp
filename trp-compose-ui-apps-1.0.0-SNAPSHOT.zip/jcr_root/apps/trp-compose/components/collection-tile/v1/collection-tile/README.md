Beacon Collection Tile (v1)
====
This component is created to show the Collection Tile Components.

## Properties
All properties from Base Tile and following additional properties:
- `position`: select (default: `"vertical"`),
- `tags`: multifield (default: `""`)
  - 'tag': textfield (default: `""`)
- `colorMode`: select (default:`""`)

## Use Object
The component uses `com.trp.beacon.compose.core.models.collectiontile.v1.CollectionTile` and Sling models as its Use-objects.

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
