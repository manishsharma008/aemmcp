Beacon Base Tile (v1)
====
This component is created to act as the super Type for the other Tile Components. NOT to be used directly.

[Beacon Base Tile Architecture](https://gitlab.awstrp.net/ui-kit/foundation/-/blob/next/packages/components/tiles/tile.docs.md)

## Properties
- `file`: Image (default: `""`)
- `altText`: string (default: `"`)
- `eyebrow`: string (default: `""`)
- `title`: string (default: `""`), required
- `description`: richText (default: `""`)
- `footnote`: richText (default: `""`)
- `titleLink`: string (default: `""`)
- `cta`: multifield 
  - `label`: string (default: `""`)
  - `link`: string (default: `""`)
  - `icon`: pathField
  - `iconAlign`: select (default: `"left"`)
  - `ariaLabel`: string (default: `""`)
  - `variant`: select (default: `"primary"`)
  - `scale`: select (default: `"normal"`)
- `mode`: select (default: `'beacon-on-light'`)

## Use Object
The component uses `com.trp.beacon.compose.core.models.basetile.v1.BaseTile` and Sling models as its Use-objects.

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
