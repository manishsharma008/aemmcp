Beacon Tabs (v2)
====


## Features
* Configurable **Variant** via select dropdown `./variant`
* Configurable **Tab Type**  via select dropdown `./tabType`

## Use Object
The Tabs component uses `com.trp.aem.trp-compose.core.models.Tabs` and Sling models as its Use-objects. (Example)

## Information
* **Vendor**: T.Rowe Price
* **Version**: v2
* **Compatibility**: AEM 6.5