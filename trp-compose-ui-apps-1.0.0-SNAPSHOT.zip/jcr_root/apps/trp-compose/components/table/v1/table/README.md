Beacon Table (v1)
====
This component is created so that the Beacon Table can be added to a page.

## Notes:
- The property ./html has been changed from textArea to RTE, so that table can be easily authored.


## Properties
- `tableVariant`: select (default: `"normal"`),
- `html`: Rich Text (default: `""`)
- `id`: string (default: `""`)
- `style`: select (default: `''`)

## Use Object
The component uses `com.trp.beacon.compose.core.models.table.v1.Table` and Sling models as its Use-objects.

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
