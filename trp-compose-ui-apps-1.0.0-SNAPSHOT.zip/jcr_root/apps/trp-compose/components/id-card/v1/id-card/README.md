Beacon ID-Card (v1)
====


## Features
* Configurable **Scale** via select dropdown `scale`
* Configurable **First Name**  via select textfield `./firstName`
* Configurable **Last name**  via select textfield `./lastName`
* Configurable **Job Title**  via textfield `./jobTitle`
* Configurable **Avatar URL**  via pathfield `./avatarUrl`
* Configurable **Bio URL**  via textfield `./bioUrl`
* Configurable **Bio Description**  via Rich Text `./bio`

## Use Object
The ID-Card component uses `com.trp.aem.trp-compose.core.models.IdCard.v1` and Sling models as its Use-objects. (Example)

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
