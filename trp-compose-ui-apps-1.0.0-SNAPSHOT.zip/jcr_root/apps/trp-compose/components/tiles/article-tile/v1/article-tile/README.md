Beacon Article Tile (v1)
====
This component is created to show the Article Tile Components.

## Usage
This component can be configured in 2 ways

The first is to reference the article page directly. Once configured the Article Tile will render using the content from the content fragment referenced by the page
The second is to select to override the fields whereby an author can manually enter the content that will be rendered in the Article Tile itself

## Properties
All properties from Base Tile and following additional properties:
- `position`: select (default: `"vertical"`),
- `layout`: select (default: `"standard"`),
- `scale`: select (default: `"normal"`),
- `byline`: checkbox (default: `"false"`)

## Use Object
The component uses `com.trp.beacon.compose.core.models.articletile.v1.ArticleTile` and Sling models as its Use-objects.

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
