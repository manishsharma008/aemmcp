

Beacon Modal (v1)
====


## Features
* Configurable **Modal Title**  `./title`
* Configurable **Modal Description**  `./description`
* Configurable **Size Variant** via select dropdown `./mini`, `./normal`, `./jumbo`, `./maxi`
* Configurable **Layout Order** via select dropdown `./0`, `./1`, `./2`, `./3`
* Configurable **Is Open**  `./isOpen`
* Configurable **Open By CSS Selectors (Foundation version 3.4.0+)**  `./openBy` [Multifield]
* Configurable **Close on Click Out**  `./closeOnClickOut`
* Configurable **Remove Close Button**  `./removeCloseButton`
* Configurable ID attribute `./id`
* Allowed components can be configured through policy configuration.

## Use Object
The Modal component uses `com.trp.beacon.compose.core.models.overlays.modal.v1.Modal` and Sling models as its Use-objects. (Example)

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
