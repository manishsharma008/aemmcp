Beacon Video (v1)
====
This component is created to show the Video Components.

[Beacon Video Architecture](https://gitlab.awstrp.net/ui-kit/foundation/-/blob/next/packages/components/video/video.docs.md)

## Properties
- `mode`: select (default: `'beacon-on-light'`)

## Use Object
The component uses `com.trp.beacon.compose.core.models.video.v1.video` and Sling models as its Use-objects.

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
