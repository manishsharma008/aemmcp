Beacon Bio Card Component (v3)
====
This component is to ingest ID Card and Data List components instead of embedding it separately.
Using this component authors need to make changes at one place (this component's dialog) instead of redundant changes in multiple components.

## Properties
- `layout`: select layout of the component 
- `template`: select template of the component
- `heroPosition`: choose a position if authoring a Hero Bio-Card
- `id`: ID in case to anchor the component
- `idCard` : Option to embed ID Card component (v1/v2)
- `dataList` : Option to embed Data List component (v1/v2)

## Information
* **Vendor**: T.Rowe Price
* **Version**: v3
* **Compatibility**: AEM 6.5