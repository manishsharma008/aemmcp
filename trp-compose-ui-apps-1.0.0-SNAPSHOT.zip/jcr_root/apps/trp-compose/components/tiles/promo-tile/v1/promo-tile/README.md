Beacon Promo Tile (v1)
====
This component is created to show the Promo Tile Components.

## Properties
- `position`: select (default: `"vertical"`),
- `layout`: select (default: `"standard"`),
- `scale`: select (default: `"normal"`),
- `eyebrow`: string (default: `""`)
- `title`: string (default: `""`), required
- `mode`: select (default: `'beacon-on-light'`)

## Use Object
The component uses `com.trp.beacon.compose.core.models.promotile.v1.PromoTile` and Sling models as its Use-objects.

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
