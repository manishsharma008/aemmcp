Beacon Contact Tile (v1)
====
This component is created to show the Contact Tile Component.

## Properties
- `altText`: string (default: `"`)
- `title`: string (default: `""`), required
- `description`: richText (default: `""`)
- `job title` (default: `""`)
- `phone` (default: `""`)
- `email` (default: `""`)
- `titleLink`: string (default: `""`)
- `cta`: multifield 
  - `label`: string (default: `""`)
  - `link`: string (default: `""`)
  - `ariaLabel`: string (default: `""`)
- `mode`: select (default: `'beacon-on-light'`)

## Use Object
The component uses `com.trp.beacon.compose.core.models.contacttile.v1.ContactTile` and Sling models as its Use-objects.

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
