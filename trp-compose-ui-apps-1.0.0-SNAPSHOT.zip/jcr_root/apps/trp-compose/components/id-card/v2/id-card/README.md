Beacon ID-Card (v2)
====

V2 ID Card compatible with Foundation V3 and Bios V2
Using this locally requires TRP-ECL Bios Setup and Configuration. See Below
https://troweprice.atlassian.net/wiki/spaces/87569/pages/3676275595/TRP+ECL#Pre-requisites

## Features
* Configurable **Scale** via select dropdown `scale`
* Configurable **Author**  via datasource dropdown `./author`
* Configurable **Bio URL**  via textfield `./bioUrl`
* Configurable **Override Avatar Url**  via checkbox `./overrideAvatarUrl`
* Configurable **Avatar URL**  via pathfield `./avatarUrl`
* Configurable **Override Bio**  via checkbox `./overrideBio`
* Configurable **Bio Description**  via Rich Text `./bio`

## Use Object
The ID-Card component uses `com.trp.aem.trp-compose.core.models.IdCard.v2` and Sling models as its Use-objects. (Example)

## Information
* **Vendor**: T.Rowe Price
* **Version**: v2
* **Compatibility**: AEM 6.5
