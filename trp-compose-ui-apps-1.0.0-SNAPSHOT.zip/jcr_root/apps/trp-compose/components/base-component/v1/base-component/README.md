Beacon Base Component (v1)
====
This component is created to act as the super Type for the other Components. NOT to be used directly.

## Properties
- `mode`: select (default: `'beacon-on-light'`)

## Information
* **Vendor**: T.Rowe Price
* **Version**: v1
* **Compatibility**: AEM 6.5
